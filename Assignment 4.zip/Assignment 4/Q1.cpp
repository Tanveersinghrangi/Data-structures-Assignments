#include<iostream>
using namespace std;

class queue{
    int rear;
    int front;
    int arr[10];
    public :
    queue(){
        rear = front =-1;
    }
    bool isfull(){
       return (rear==9);
    }
    bool isempty(){
        return(rear==-1);
    }
    void enqueue(int x){
        if(isfull()){
            cout<<"Queue is already full";
            return;
        }
        if(isempty()){
            front =0;
        }
        rear ++;
        arr[rear]=x;
    }
    void dequeue(){
        if(isempty()){
            cout<<"Queue is already empty";
            return;
        }
        front++;
        if(front>rear){
            front =rear =-1;
        }
    }
    int size(){
       return rear -front+1;   
    }
    void peek(){
        cout<<arr[front];
    }
    void display(){
         if (isempty()){
            cout << "Queue is already empty\n";
            return;
        }
        for(int i=front;i<=rear;i++){
            cout<<arr[i]<<endl;
        }
    }
};
int main(){
    queue q;
   int siz=q.size();
    cout<<".........MENU.........";
cout<<"1.ENQUEUE"<<endl<<"2.DEQUEUE\n3.DISPLAY\n4.PEEK\n5.SIZE\n6.EXIT"<<endl;
int choice;
 while (choice!=6){
 cout<<"Enter your choice: ";
        cin>>choice;
       
switch(choice){
    case 1 :
        int x;
        cout<<"Enter the value of x";
        cin>>x;
        q.enqueue(x);
        break;
    
    case 2 : q.dequeue();  break;
    case 3 : q.display();  break;
    case 4 : q.peek();  break;
    case 5 : cout<<siz;  break;
    default: cout<<"Invalid choice \n";
}
}
system("pause");
return 0;
}
