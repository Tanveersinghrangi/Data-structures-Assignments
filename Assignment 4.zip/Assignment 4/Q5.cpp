#include <iostream>
using namespace std;

class Queue {
    int arr[100];
    int front, rear;
public:
    Queue() { front = rear = -1; }
    void enqueue(int x) {
        if (rear == 99) return;
        if (front == -1) front = 0;
        arr[++rear] = x;
    }
    void dequeue() {
        if (front == -1) return;
        front++;
        if (front > rear) front = rear = -1;
    }
    int frontVal() {
        if (front == -1) return -1;
        return arr[front];
    }
    bool empty() {
        return front == -1;
    }
    int size() {
        if (front == -1) return 0;
        return rear - front + 1;
    }
};

// (a) Stack using Two Queues
class Stack2{
    Queue q1, q2;
public:
    void push(int x) {
        q2.enqueue(x);
        while (!q1.empty()) {
            q2.enqueue(q1.frontVal());
            q1.dequeue();
        }
        Queue temp = q1;
        q1 = q2;
        q2 = temp;
    }
    void pop() {
        if (!q1.empty()) q1.dequeue();
    }
    int top() {
        if (q1.empty()) return -1;
        return q1.frontVal();
    }
    bool empty() {
        return q1.empty();
    }
};

// (b) Stack using One Queue
class Stack1 {
    Queue q;
public:
    void push(int x) {
        q.enqueue(x);
        int n = q.size();
        for (int i = 0; i < n - 1; i++) {
            int temp = q.frontVal();
            q.dequeue();
            q.enqueue(temp);
        }
    }
    void pop() {
        if (!q.empty()) q.dequeue();
    }
    int top() {
        if (q.empty()) return -1;
        return q.frontVal();
    }
    bool empty() {
        return q.empty();
    }
};

int main() {
    Stack1 s1;
    s1.push(1);
    s1.push(2);
    s1.push(3);
    cout << "Stack using two queues top: " << s1.top() << endl;
    s1.pop();
    cout << "After pop top: " << s1.top() << endl;

    Stack2 s2;
    s2.push(4);
    s2.push(5);
    s2.push(6);
    cout << "Stack using one queue top: " << s2.top() << endl;
    s2.pop();
    cout << "After pop top: " << s2.top() << endl;
    system("pause");        
    return 0;
}
