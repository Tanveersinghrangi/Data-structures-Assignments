#include <iostream>
#include <string>
using namespace std;

class Queue {
    char arr[100];
    int front, rear;
public:
    Queue() { front = rear = -1; }
    void enqueue(char c) {
        if (rear == 99) return;
        if (front == -1) front = 0;
        arr[++rear] = c;
    }
    void dequeue() {
        if (front == -1) return;
        front++;
        if (front > rear) front = rear = -1;
    }
    char frontChar() {
        if (front == -1) return '\0';
        return  arr[front];
    }
    bool empty() {
        return  front == -1;
    }
};

int main() {
    string s;
    getline(cin, s);
    int freq[256] = {0};
    Queue q;
    for (int i = 0; i < s.size(); i++) {
        if (s[i] == ' ') continue;
        freq[s[i]]++;
        q.enqueue(s[i]); 
        while ( !q.empty() && freq[q.frontChar()] > 1) q.dequeue();
        if (q.empty())   cout << "-1 ";
        else cout << q.frontChar() << " ";
    }   
    system("pause");   
    return 0;
}
