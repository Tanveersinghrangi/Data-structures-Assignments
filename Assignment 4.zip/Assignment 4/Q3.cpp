#include<iostream>
#include<queue>
using namespace std;

void interleave(queue<int> &q){
    int n=q.size();
    int half =n/2;
    queue<int> half1;
    
    for(int i=0;i<half;i++){
        half1.push(q.front());
        q.pop();
    }
    while(!half1.empty()){
        q.push(half1.front());
        half1.pop();
        
        q.push(q.front());
        q.pop();
    }
}
int main(){
    queue<int> q;
    int n,val;
    cout<<"Enter the no of elements";
    cin>>n;
    cout<<"Enter the elements";
    for(int i=0;i<n;i++){
        cin>>val;
        q.push(val);
    }
    interleave(q);
    cout<<"The desired queue is :";
    while(!q.empty()){
        cout<<q.front()<<endl;
        q.pop();
        }
        return 0;
        system("pause");   
        return 0;
}