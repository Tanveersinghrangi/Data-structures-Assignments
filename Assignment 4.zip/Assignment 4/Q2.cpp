#include<iostream>
using namespace std;

class circularqueue{
    int rear;
    int front;
    int arr[5];
    int size;
    public :
    circularqueue(){
        rear = front =-1;
        size =5;
    }
    bool isfull(){
       return (front==(rear+1)%size);
    }
    bool isempty(){
        return( front==-1);
    }
    void enqueue(int x){
        if(isfull()){
            cout<<"Queue is already full";
            return;
        }
        if(isempty()){
            front =rear =0;
        }
        else{
        rear=(rear +1)%size;}
        arr[rear]=x;
        cout<<x<<" Inserted\n";
        
    }
    void dequeue(){
        if(isempty()){
            cout<<"Queue is already empty";
            return;
        }
        cout<<arr[front]<<" removed from queue\n";
        if(front==rear){
            front =rear =-1;
        }
        else{
            front=(front+1)%size;
        }
    }
    int getsize(){
        if(rear>=front){
       return rear -front+1;}
       else{
       return size -front +rear +1;
       }
    }
    void peek(){
        cout<<arr[front];
    }
    void display(){
         if (isempty()){
            cout << "Queue is already empty\n";
            return;
        }
        int i=front;
        while(true){
            cout<<arr[i]<<" ";
            if(i==rear)break;
            i=(i+1)%size;
        }
        cout<<endl;
    }
};
int main(){
    circularqueue q;
    cout<<".........MENU.........";
cout<<"1.ENQUEUE"<<endl<<"2.DEQUEUE\n3.DISPLAY\n4.PEEK\n5.SIZE\n6.EXIT"<<endl;
int choice=0;
 while (choice!=6){
 cout<<"Enter your choice: ";
        cin>>choice;
       
switch(choice){
    case 1 :
        int x;
        cout<<"Enter the value of x";
        cin>>x;
        q.enqueue(x);
        break;
    
    case 2 : q.dequeue();  break;
    case 3 : q.display();  break;
    case 4 : q.peek();  break;
    case 5 : cout<<q.getsize()<<endl;  break;
    default: cout<<"Invalid choice \n";
}
}
system("pause");
return 0;
}
