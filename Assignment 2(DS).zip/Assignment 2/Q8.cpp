#include<iostream>
using namespace std;

int distinct(int arr[],int n){
    int count=0;
    for (int i=0;i<n;i++){
int j;
        for (j=0;j<i;j++){
            if (arr[i]==arr[j]){
            
                break;
            }
        }
            if(j==i){
            count++;
            }
        
    }
    return count;
    
}
 int main(){
     int arr[100];

       int n;
      cout<<"Enter no of elements in array";
      cin>>n;
     cout<<"Enter your array";
     for (int i=0;i<n;i++){
         cin>>arr[i];
     }
     int count =distinct(arr,n);
     cout<<"The number of distinct elements in the array are :"<<count<<endl;
     system("pause");        
     return 0;
 }