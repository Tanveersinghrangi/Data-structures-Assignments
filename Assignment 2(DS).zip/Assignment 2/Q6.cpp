#include <iostream>
using namespace std;

int main() {
    int row,col,n;
    cout<<"Enter the number of rows,columns and values";
    cin>>row>>col>>n;
    int triplet[100][3];
    cout<<"Enter the lements in triplet form (row col value) ";
    triplet[0][0]=row;
    triplet[0][1]=col;
    triplet[0][2]=n;
    for (int i=1;i<=n;i++){
        cin>>triplet[i][0]>>triplet[i][1]>>triplet[i][2];
    }
    int trans[100][3];
    trans[0][0]=col;
       trans[0][1]=row;
          trans[0][2]=n;
          
    int k = 1;
    for (int c = 0; c < col; c++) {
        for (int i = 1; i <= n; i++) {
            if (triplet[i][1] == c) {
                trans[k][0] = triplet[i][1];
                trans[k][1] = triplet[i][0];
                trans[k][2] = triplet[i][2];
                k++;
            }
        }
    }

    cout << "\nTranspose (Triplet Form):\n";
    cout << "Row Col Val\n";
    for (int i = 0; i <= n; i++) {
        cout << trans[i][0] << "   " << trans[i][1] << "   " << trans[i][2] << endl;
    }

    return 0;
    system("pause");        
        return 0;
}

