#include <iostream>
#include<string>
using namespace std;

int main() {
   char ch;
   cout<<"Enter the uppercase letter";
   cin>>ch;
   if(ch>='A'&& ch<='z'){
       ch=ch+32;
   }
   else{
       cout<<"The character is not an uppercase letter";
   }
   cout<<"The letter in lowercase is : "<<ch<<endl;
   
    return 0;
    system("pause");        
        return 0;
}
