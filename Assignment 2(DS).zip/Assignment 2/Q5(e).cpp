#include <iostream>
using namespace std;

class symmetric {
    int n;
    int *A;
public:
    symmetric(int n) {
        this->n = n;
        A = new int[n * (n + 1) / 2];
        for (int i = 0; i < n * (n + 1) / 2; i++) A[i] = 0;
    }

    void set(int i, int j, int x) {
        if (i >= j) {
            A[(i * (i - 1)) / 2 + (j - 1)] = x;
        }
    }

    int get(int i, int j) {
        if (i >= j) {
            return A[(i * (i - 1)) / 2 + (j - 1)];
        } else {
            return A[(j * (j - 1)) / 2 + (i - 1)];
        }
    }

    void display() {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                cout << get(i, j) << " ";
            }
            cout << endl;
        }
    }
};

int main() {
    int n = 4;
    symmetric t(n);
    t.set(1,1,1);
    t.set(2,1,5);
    t.set(3,1,6);
    t.set(4,1,7);
    t.set(2,2,2);
    t.set(3,2,4);
    t.set(3,3,5);
    t.set(4,2,2);
    t.set(4,3,3);
    t.set(4,4,4);

    cout << "The symmetric matrix is:" << endl;
    t.display();
}
