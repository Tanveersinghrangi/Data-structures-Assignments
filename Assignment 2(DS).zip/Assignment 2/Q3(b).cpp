
#include<iostream>
using namespace std;
int binarysearch(int arr[],int n){
    int high =n-1;
    int low =0;
    while (low<=high){
        int mid =(high +low)/2;
        if (arr[mid]==mid+1){
            low =mid+1;
        }
        else{
            high =mid-1;
        }
    }
        return low+1;
}
int main() {
    int arr[100];
    int n ;
    cout<<"Enter the number of elements ";
    cin>>n;
    cout<<"Type the elements of array : ";
    for (int i=0;i<n;i++){
        cin>>arr[i];
    }
   
    int result =binarysearch(arr,n);
   cout <<"The missing number in array is :"<<result<<endl;
   system("pause");        
   return 0;
}