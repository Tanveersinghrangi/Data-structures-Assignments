#include <iostream>
#include<string>
using namespace std;

int main() {
    string str;
    cout<<"Enter the string ";
    cin>>str;
    int n =str.length();
    for (int i=0;i<n-1;i++){
        for(int j=0;j<n-1-i;j++){
        if(str[j]>str[j+1]){
            char temp =str[j];
            str[j]=str[j+1];
            str[j+1] =temp;
        }
    }
    }
    cout<<"The string in alphabetical order is : "<<str<<endl;
    return 0;
    system("pause");        
        return 0;
}
