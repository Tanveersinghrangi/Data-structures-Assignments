
#include<iostream>
using namespace std;
int linearsearch(int arr[],int n){
    for (int i=0;i<n;i++){
        if (arr[i]!=i+1){
            return i+1;
        }
    }
    return -1;
}

int main() {
    int arr[100];
    int n ;
    cout<<"Enter the number of elements ";
    cin>>n;
    cout<<"Type the elements of array : ";
    for (int i=0;i<n;i++){
        cin>>arr[i];
    }
    int result =linearsearch(arr,n);
    
   cout <<"The missing number in array is :"<<result<<endl;
   system("pause");        
   return 0;
   
}