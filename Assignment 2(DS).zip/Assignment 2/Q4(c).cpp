#include <iostream>
#include<string>
using namespace std;

int main() {
    string str;
    cout<<"Enter the string ";
    cin>>str;
string result;
int n =str.length();
for(int i=0;i<n;i++){
    if(str[i]=='a' || str[i]=='e' || str[i]=='i' || str[i]=='o' ||    str[i]=='u' || str[i]=='A' || str[i]=='E' || str[i]=='I' || str[i]=='O' ||str[i]=='U' ){
        continue;
    }
    result += str[i];
}
cout<<"The string without vowels is : "<<result<<endl;
    return 0;
    system("pause");        
        return 0;
}
