#include<iostream>
using namespace std;

int inversion(int arr[],int n){
    int count=0;
    for (int i=0;i<n;i++){
        for (int j=0;j<n;j++){
            if (i<j && arr[i]>arr[j]){
                count ++;
            }
        }
    }
    return count;
    
}
 int main(){
     int arr[100];

       int n;
      cout<<"Enter no of elements in array";
      cin>>n;
     cout<<"Enter your array";
     for (int i=0;i<n;i++){
         cin>>arr[i];
     }
     int count =inversion(arr,n);
     cout<<"The number of inversions in the array are :"<<count<<endl;
     system("pause");        
     return 0;
 }