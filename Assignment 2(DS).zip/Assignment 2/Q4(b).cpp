#include <iostream>
#include<string>
using namespace std;

int main() {
    string str;
    cout<<"Enter the string you want to reverse ";
    cin >> str;

int n =str.length();
for(int i=0;i<n/2;i++){
    int temp =str[i];
    str[i]=str[n-1-i];
    str[n-1-i]=temp;
}
cout<<"The reversed string is : "<<str<<endl;
    return 0;
    system("pause");        
        return 0;
}
