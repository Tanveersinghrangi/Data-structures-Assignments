#include <iostream>
using namespace std;

class triDiagonal{
    int n;
    int *A;
    public:
    triDiagonal(int n){
        this->n=n;
        A=new int[3*n-2];
        for(int i=0;i<3*n-2;i++)A[i]=0;
    }
            void set(int i,int j ,int x){
                if(i-j==1){A[i-2]=x;}
               else if(i==j ){A[n+i-2]=x;}
               else if(i-j==-1){A[2*n-1+i-1]=x;}

                }
            
               int get(int i,int j){
                   if(i-j==1){return A[i-2];}
               else if(i==j ){return A[n+i-2];}
               else if(i-j==-1){return A[2*n-1+i-1];}
               
               else {return 0;}
               }
            void display(){
                for(int i=1;i<=n;i++){
                    for(int j=1;j<=n;j++){
                        cout<<get(i,j)<<" ";
                }
                cout<<endl;
        }
    }
};
int main() {
   int n=4;
   triDiagonal t(n);
  t.set(1,1,4);
    t.set(1,2,5);
    t.set(2,1,6); t.set(2,2,7); t.set(2,3,8);
    t.set(3,2,9); t.set(3,3,10); t.set(3,4,11);
    t.set(4,3,12); t.set(4,4,13);
  
   cout<<"The matrix is :"<<endl;
   
   t.display();
   system("pause");        
   return 0;
}
