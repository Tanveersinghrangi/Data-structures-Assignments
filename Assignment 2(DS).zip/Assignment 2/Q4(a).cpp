#include <iostream>
using namespace std;

int main() {
    char str1[100], str2[100];
    
    cout << "Enter first string: ";
    cin >> str1;

    cout << "Enter second string: ";
    cin >> str2;

    // We will concatenate here by the basc c-style string approach
        
    int i = 0, j = 0;


    while (str1[i] != '\0') {
        i++;
    }

    
    while (str2[j] != '\0') {
        str1[i] = str2[j];
        i++;
        j++;
    }


    str1[i] = '\0';

    cout << "The Concatenated string is: " << str1 << endl;

    return 0;
    system("pause");        
        return 0;
}
