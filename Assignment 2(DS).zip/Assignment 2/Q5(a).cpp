#include <iostream>
using namespace std;

class Diagonal{
    int n;
    int *A;
    public:
    Diagonal(int n){
        this->n=n;
        A=new int[n];
        for(int i=0;i<n;i++)A[i]=0;
    }
            void set(int i,int j ,int x){
                if(i==j){
                 A[i]=x;
                }
            }
               int get(int i,int j){
                   if(i==j){return A[i];
               }
               else { return 0;
               }
               }
            void display(){
                for(int i=0;i<n;i++){
                    cout<<" ";
                    for(int j=0;j<n;j++){
                        if(i==j){
                            cout<<A[i]<<" ";
                        }
                        else {
                            cout << "0 ";
                        }
                }
                cout<<endl;
        }
    }
};
int main() {
   int n=4;
   Diagonal d(n);
    d.set(0,0,1);
   d.set(1,1,2);
   d.set(2,2,4);
   d.set(3,3,3);
  
   cout<<"The matrix is :"<<endl;
   
   d.display();
   system("pause");        
   return 0;
}
