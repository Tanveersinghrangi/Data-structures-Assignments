
#include<iostream>
using namespace std;

int binarysearch(int arr[],int n,int key){
    int high=n-1;
    int low=0;
    while (low<=high){
        int mid = (high +low)/2;
        if(arr[mid]==key){
            return mid;
        }
        else if(arr[mid]<key){
            low =mid +1;
        }
        else {
            high =mid -1;
        }
    }
return -1;
    
}
int main() {
    int n;
    int arr[100];
    int key;
    cout<<"Enter the number of elements in array";
    cin>>n;
    for (int i=0;i<n;i++){
        cin>>arr[i];
    }
    cout<<"Enter th element you want to find " ;
    cin>>key;
    int result =binarysearch(arr,n,key);
    if (result !=-1){
    cout<<"Your element was found at index "<<result<<endl;}
    else {
        cout<<"Your element was not found";
    }
   
}