#include<iostream>
using namespace std;
#define MAX 100
class stack{
      public:
    int top;
    int arr[MAX];
 
    stack(){
        top =-1;
    }
    int isempty(){
        if(top==-1){
            return 1;
        }
        else{
            return 0;
        }
    }
     int isfull(){
        if(top==MAX-1){
            return 1;
        }
        else{
            return 0;
        }
    }
    void push(int value){
        if(isfull()){
            cout<<"Stack overflowed";
        }
        else{
            arr[++top]=value;
            cout<<value<<" pushed into stack"<<endl;
        }
    }
    void pop(){
        if(isempty()){
            cout<<"Stack has underflowed";
        }
        else{
            cout<<arr[top--]<<" removed from stack"<<endl;
        }
    }
    void display(){
        for(int i=top;i>=0;i--){
            cout<<arr[i]<<" ";
        }
        cout<<endl;
    }
    void peek(){
         if(isempty()){
            cout<<"Stack has no element";
    }
    else{
        cout<<"The top element is "<<arr[top]<<endl;
    }
    }
};
int main() {
    stack s;
    int choice;
    cout<<".........MENU........"<<endl;
    cout<<"1.Push"<<endl;
    cout<<"2.Pop"<<endl;
    cout<<"3.Peek"<<endl;
    cout<<"4.Display"<<endl;
    cout<<"Enter your choice";
    cin>>choice;
    switch(choice){
        case 1:
        cout<<"Enter the value to be pushed";
            int value;
            cin>>value;
            s.push(value);
            break;
        case 2:
            s.pop();
            break;
        case 3:
            s.peek();
            break;
        case 4:
            s.display();
            break;
        default:
            cout<<"Invalid choice";
    }
    system("pause");        
        return 0;
}