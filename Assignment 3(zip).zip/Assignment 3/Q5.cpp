#include <iostream>
#include<stack>
#include<string>
#include<cmath>
using namespace std;

int evaluatepost(string str){
    stack<char> s;
    for(int i=0;i<str.size();i++){
        char ch =str[i];
        if (ch==' ')continue;
        if (ch>='0' && ch<='9'){
            s.push(ch-'0');
        }
        else{
            int op1 =s.top();s.pop();
            int op2 =s.top();s.pop();
            int result;
            switch(ch){
            case '+' : result = op1 +op2;break;
            case '-': result =op2-op1;break;
            case '*': result =op1*op2;break;
            case '/': result = op2/op1;break;
            case '^': result =pow(op2,op1);break;
            s.push(result);
        }
    }
    return s.top();
}
}
int main() {
  string str;
  cout << "Enter to evaluate a postifx expression"<<endl;
  getline(cin , str);
 int result = evaluatepost(str);
 cout<<"The answer is :"<<result<<endl;
    return 0;
    system("pause"); 
    return 0;
}