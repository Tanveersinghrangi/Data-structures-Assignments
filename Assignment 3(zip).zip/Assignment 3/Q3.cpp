#include <iostream>
#include<stack>
#include<string>
using namespace std;

int parenthesis(string str){
    stack<char> s ;
    int i =0;
    
    while(i<str.size()){
        char ch = str[i];
        if (ch=='(' || ch=='{'|| ch=='['){
  s.push(ch);
        }
        if(ch==')'||ch=='}'||ch==']'){
        if(s.empty()){
            return 0;
        }
        
        if((ch==')' && s.top()!='(') ||
        (ch=='}' && s.top()!='{') ||
        (ch==']' && s.top()!='[')){
            return 0;
        }
        s.pop();
        }
        i++;
    }
    return s.empty();
}
int main() {
  string str;
  cout << "Enter to check balanced parenthesies";
  getline(cin , str);
 if (parenthesis(str)){
     cout<<"Balanced parenthresis"<<endl;
 }
     else{
     cout<<"Unbalanced parenthesis"<<endl;
 }

    return 0;
    system("pause"); 
    return 0;
}