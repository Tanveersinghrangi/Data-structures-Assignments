#include <iostream>
#include<stack>
#include<string>
using namespace std;

int precedence(char op) {
    if (op == '^')
        return 3;
    if (op == '*' || op == '/')
        return 2;
    if (op == '+' || op == '-')
        return 1;
    return 0;
}
int isoperator(char ch){
    if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^')
        return 1;
        return 0;
}
string conversion(string str){
    stack<char> s ;
    string post = "";
    
    int i =0;
    while(i<str.size()){
        char ch = str[i];
        if ((ch>='a' && ch<='z') || (ch>='A' && ch<= 'Z') || (ch>='0' && ch<='9')){
        post += ch;
        }
        else if(ch=='('){
            s.push(ch);
        }
        else if(ch==')') {
            while(!s.empty() && s.top()!='('){
                post += s.top();
                s.pop();
            }
            s.pop();
        }
        else if(isoperator(ch)){
            while (!s.empty() && precedence(s.top())>=precedence(ch)){
                post += s.top();
                s.pop();
            }
            s.push(ch);
        }
        i++;
    }
    while (!s.empty()){
        post += s.top();
        s.pop();
    }
    return post;
}
int main() {
  string str;
  cout << "Enter an infix expression";
  getline(cin , str);
 
 
  string postfix = conversion(str);
   cout<<"The postfix expression for this is: "<<postfix;
  

   
    system("pause");   
    return 0;
}