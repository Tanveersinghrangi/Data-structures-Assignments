#include<iostream>
#include<string>
#include<stack>
using namespace std;

int main() {
    string str;
    cout<<"Enter the string";
    cin>>str;
    stack<char>st;
    int n =str.length();
    for(int i=0;i<n;i++){
        st.push(str[i]);
    }
    string reversedStr = "";
    while (!st.empty()) {
        reversedStr += st.top(); 
        st.pop();                
    }
    cout<<"The reversed string is "<<reversedStr<<endl;
    system("pause");    
    return 0;
}