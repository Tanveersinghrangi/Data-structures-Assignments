#include<iostream>
using namespace std;
int forpivot(int arr[],int l,int r){
    int pivot=arr[r];
    int i=l-1;
    for(int j=0;j<r;j++){
        if(arr[j]<pivot){
            i++;
            int temp=arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
        }
    }
    int temp=arr[i+1];
    arr[i+1]=arr[r];
    arr[r]=temp;
    return i+1;
}
void quicksort(int arr[],int l,int r){
    if(l<r){
        int pi=forpivot(arr,l,r);
        
        quicksort(arr,l,pi-1);
        quicksort(arr,pi+1,r);
    }
}
int main(){
    int n;
    cout<<"Enter size: ";
    cin>>n;

    int arr[n];
    cout<<"Enter elements: ";
    for(int i=0; i<n; i++) cin>>arr[i];

    quicksort(arr, 0,n-1);

    cout<<"Sorted array is : ";
    for(int i=0; i<n; i++) cout<<arr[i]<<" ";

    return 0;
}
