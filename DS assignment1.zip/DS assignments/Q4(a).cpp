#include<iostream>
using namespace std ;

void reversearray(int arr[],int n){
           
           int i=0;
            int j=n-1;
            while(i<j){
            int temp;
            temp =arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
            i++;
            j--;
        }
        
    }
    
    
    

 int main (){
     int arr[100];
     int n;
     cout<<"Enter the size of array";
     cin>>n;
     cout<<"Enter the elements of the array";
     for (int i=0;i<n;i++){
         cin>>arr[i];
     }
     reversearray(arr,n);
     cout<<"The elements after reversing are:\n";
     for (int i=0;i<n;i++){
         cout<<arr[i]<<endl;
     }
    system("pause");
     return 0;
 }