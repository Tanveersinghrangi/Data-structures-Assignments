#include<iostream>
using namespace std ;

void removeduplicate(int arr[],int &n){
if (n==0 |n==1){
    cout<<"No duplicate elements";
}
for (int i=0;i<n;i++){
    for (int j=i+1;j<n;j++){
        if (arr[i]==arr[j]){
            for (int k=i+1;k<n-1;k++){
                arr[k]=arr[k+1];
            }
            n--;
            j--;
        }
    }
}
}   
 int main (){
     int arr[100];
     int n;
     cout<<"Enter the size of array";
     cin>>n;
     cout<<"Enter the elements of the array";
     for (int i=0;i<n;i++){
         cin>>arr[i];
     }
     removeduplicate(arr,n);
     cout<<"The elements after removing duplicates are:\n";
     for (int i=0;i<n;i++){
         cout<<arr[i]<<endl;
     }
     system("pause");
     return 0;
    
 }