#include<iostream>
using namespace std ;

void rowsum(int arr[100][100],int r1,int c1){
 
    for (int i=0;i<r1;i++){
        int sum =0;
        for (int j=0;j<c1;j++){
            sum += arr[i][j];
        }
        cout<<"Sum of row"<<i+1<<" is"<<" "<<sum<<endl;
    }
          
    }
    void colsum(int arr[100][100],int r1,int c1){
 
    for (int i=0;i<c1;i++){
        int sum =0;
        for (int j=0;j<r1;j++){
            sum += arr[j][i];
        }
        cout<<"Sum of column"<<i+1<<" is"<<" "<<sum<<endl;
    }
          
    }
    
    
    

 int main (){
     int arr[100][100];
     int r1,c1;
     cout<<"Enter the number of rows and columns of the matrix";
     cin>>r1>>c1;
     
     cout<<"Enter the elements of the matrix";
     for (int i=0;i<r1;i++){
         for (int j=0;j<c1;j++){
             cin>>arr[i][j];
         }
     }
     
     cout<<"the transposed matrix is ;\n";
     rowsum(arr,r1,c1);
     colsum(arr,r1,c1);

     
    system("pause");
     return 0;
    
 }