#include <iostream>
using namespace std;

int n;              
int arr[100];       

void createArray() {
    cout << "Enter size of array: ";
    cin >> n;
    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }
}

void displayArray() {
    cout << "Array elements: ";
    for (int i = 0; i < n; i++) {
        cout << arr[i] << " ";
    }
    cout << endl;
}

void insertelement(){
    int pos;
    int value;
    cout<<"Enter the element you want to insert";
    cin>>value;
    cout<<"Enter the position";
    cin>>pos;
    for (int i=n;i>=pos;i--){
        arr[i]=arr[i-1];
        
    }
    arr[pos-1]=value;
    n++;
}
void deletelement(){
    int pos;
    cout<<"Enter the element's position you want to delete";
    cin>>pos;
    for (int i=pos-1;i<n-1;i++){
        arr[i]=arr[i+1];
    }
    n--;
}
void linearsearch(){
    int a;
    cout<<"Enter the element you want to search";
    cin>>a;
    for(int i=0;i<n;i++){
        if (arr[i]==a){
            cout<<"The element is found at position:"<<i+1<<endl;
        }
        }
    }
    

int main() {
    int option;
    while (true) {
        cout << "\n........ MENU ........" << endl;
        cout << "1. CREATE\n2. DISPLAY\n3. INSERT\n4. DELETE\n5. LINEAR SEARCH\n6. EXIT\n";
        cout << "Enter your option: ";
        cin >> option;

        switch (option) {
            case 1: createArray(); break;
            case 2: displayArray(); break;
            case 3: insertelement(); break;
            case 4: deletelement(); break;
            case 5: linearsearch();break;
            case 6: return 0;
            default: cout << "Invalid choice!" << endl;
        }
    }
}
