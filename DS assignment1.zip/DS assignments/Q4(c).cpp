#include<iostream>
using namespace std ;

void transpose(int arr[100][100],int tar[100][100],int r1,int c1){
 
    for (int i=0;i<r1;i++){
        for (int j=0;j<c1;j++){
            tar[j][i]=arr[i][j];
          
        }
    }
          
    }
    
    
    

 int main (){
     int arr[100][100];
     int tar[100][100];
     int r1,c1;
     cout<<"Enter the number of rows and columns of the matrix";
     cin>>r1>>c1;
     
     cout<<"Enter the elements of the matrix";
     for (int i=0;i<r1;i++){
         for (int j=0;j<c1;j++){
             cin>>arr[i][j];
         }
     }
     transpose(arr,tar,r1,c1);
     cout<<"the transposed matrix is ;\n";
      for (int i=0;i<c1;i++){
        for (int j=0;j<r1;j++){
           cout<<tar[i][j]<<" ";
          
        }
        cout<<endl;
    }
    system("pause");
     return 0;
 }