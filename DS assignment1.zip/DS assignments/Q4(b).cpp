#include<iostream>
using namespace std ;

void matrixmultiply(int arr1[100][100],int arr2[100][100],int res[100][100],int r1,int r2,int c1,int c2){
    if (c1!=r2){
        cout<<"Matrix multiplication is not possible";
        return;
    }
    for (int i=0;i<r1;i++){
        for (int j=0;j<c2;j++){
            res[i][j]=0;
        }
    }
    for (int i=0;i<r1;i++){
        for (int j=0;j<c2;j++){
            for (int k=0;k<c1;k++){
                res[i][j]=res[i][j]+arr1[i][k]*arr2[k][j];
                
            }
        
        }
    }
          
    }
    
    
    

 int main (){
     int arr1[100][100];
     int arr2[100][100];
     int res[100][100];
     int r1,r2,c1,c2;
     cout<<"Enter the number of rows and columns of first matrix";
     cin>>r1>>c1;
     cout<<"Enter the number of rows and columns of second matrix";
     cin>>r2>>c2;
     
     cout<<"Enter the elements of first matrix";
     for (int i=0;i<r1;i++){
         for (int j=0;j<c1;j++){
             cin>>arr1[i][j];
         }
     }
      
     cout<<"Enter the elements of second matrix";
     for (int i=0;i<r2;i++){
         for (int j=0;j<c2;j++){
             cin>>arr2[i][j];
         }
     }
     cout<<"The matrix after multiplication is :";
 matrixmultiply(arr1,arr2,res,r1,r2,c1,c2);
 cout<<endl;
     for (int i=0;i<r1;i++){
        for (int j=0;j<c2;j++){
            cout<<res[i][j]<<" ";
    
        }
        cout<<endl;
    }
    system("pause");
     return 0;
 }