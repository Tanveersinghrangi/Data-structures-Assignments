#include<iostream>
using namespace std;

class node{
    public:
    int data;
    node* next;

    node(int value){
        data=value;
        next=nullptr;
    }
};

class circular{
    public:
    node* head;

    circular(){
        head=nullptr;
    }

    void insertatstart(int value){
        node *n=new node(value);
        if(head==nullptr){
            head=n;
            n->next=n;
            return;
        }
        node *temp=head;
        while(temp->next!=head){
            temp=temp->next;
        }
        n->next=head;
        temp->next=n;
        head=n;
    }

    void insertatend(int value){
        node *n=new node(value);
        if(head==nullptr){
            head=n;
            n->next=n;
            return;
        }
        node *temp=head;
        while(temp->next!=head){
            temp=temp->next;
        }
        temp->next=n;
        n->next=head;
    }

    void insertafter(int key,int value){
        node *temp=head;
        while(temp->data!=key){
            temp=temp->next;
        }
        node *n=new node(value);
        n->next=temp->next;
        temp->next=n;
    }

    void deleteNode(int key){
        if(head==nullptr){
            return;
        }
        node *temp=head;
        node *prev=nullptr;

        while(temp->data!=key){
            prev=temp;
            temp=temp->next;
        }

        if(temp==head){
            node *last=head;
            while(last->next!=head){
                last=last->next;
            }
            head=head->next;
            last->next=head;
            delete temp;
            return;
        }

        prev->next=temp->next;
        delete temp;
    }

    int size(){
        if(head==nullptr){
            return 0;
        }
        int count=1;
        node *temp=head;
        while(temp->next!=head){
            temp=temp->next;
            count++;
        }
        return count;
    }

    void display(){
        if(head==nullptr){
            return;
        }
        node *temp=head;
        do{
            cout<<temp->data<<" ";
            temp=temp->next;
        }while(temp!=head);
        cout<<endl;
    }
};

int main(){
    circular cl;
    cl.insertatstart(10);
    cl.insertatstart(20);
    cl.insertatend(5);
    cl.insertafter(10,8);
    cl.display();
    cout<<cl.size();
}
