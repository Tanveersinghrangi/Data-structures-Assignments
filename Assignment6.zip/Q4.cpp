#include<iostream>
using namespace std;

class node{
      public:
    int data;
    node* prev;
    node* next;
  
    node(int value){
        data=value;
        prev=nullptr;
        next=nullptr;
    }
};
class doubly{
      public:
    node* head;
    doubly(){
        head=nullptr;
    }
    bool palindrome(){
       if(head==nullptr || head->next==nullptr){
          return true;
       }
       node *left=head;
       node *right=head;
       while(right->next!=nullptr){
           right=right->next;
       }
       while(left!=right && right->next!=left){
           if(right->data!=left->data){
        return false;
           }
           right=right->prev;
           left=left->next;
       }
       return true;
        
    }
    
    void insertatstart(int value){
        node *n=new node(value);
        if(head==nullptr){
            head=n;
            return;
        }
        n->next=head;
        head->prev=n;
        head=n;
        
    }
    
    void insertatend(int value){
        node *n=new node(value);
        if(head==nullptr){
            head=n;
            return;
        }
        node* temp=head;
        while(temp->next!=nullptr){
            temp=temp->next;
        }
        temp->next=n;
        n->prev=temp;
    }
    void insertafter(int key,int value){
        node *n=new node(value);
        node *temp=head;
        while(temp->data!=key){
            temp=temp->next;
        }
        node* after=temp->next;
        temp->next=n;
        n->prev=temp;
        n->next=after;
        if(after!=nullptr){
            after->prev=n;
        }
       
    }
    void insertbefore(int key,int value){
        node *n=new node(value);
       if(head==nullptr){
           insertatstart(value);
           return;
       }
       node* temp=head;
    if(head->data==key){
        n->next=head;
        head->prev=n;
        head=n;
        return;
    }
    while(temp->data!=key){
        temp=temp->next;
    }
    n->next=temp;
    n->prev=temp->prev;
    temp->prev->next=n;
    temp->prev=n;
    
}
  void searchnode(int key){
    node *temp=head;
    while(temp!=nullptr){
        if(temp->data==key){
            cout<<"Element found";
            return;
        }
        temp=temp->next;
    }
    cout<<"Element not found";
    
}
 void size(){
      node *temp=head;
      int count;
      while(temp!=nullptr){
          temp=temp->next;
          count++;
      }
      cout<<count<<endl;
  }
    void deleteNode(int key) {
        if(head == nullptr) {
            cout << "List is empty.\n";
            return;
        }

        node *temp = head;
        if(temp->data == key) {
            head = temp->next;
            if(head != nullptr)
                head->prev = nullptr;
            delete temp;
            return;
        }

        while(temp != nullptr && temp->data != key)
            temp = temp->next;

        if(temp == nullptr) {
            cout << "Node " << key << " not found.\n";
            return;
        }

        if(temp->next != NULL)
            temp->next->prev = temp->prev;

        if(temp->prev != NULL)
            temp->prev->next = temp->next;

        delete temp;
    }

    void display(){
        node* temp=head;
        while(temp!=nullptr){
            cout<<temp->data<<" ";
            temp=temp->next;
        }
    }
    
};



int main() {
    doubly dl;
    int choice, val, key;

    dl.insertatstart(10);
    dl.insertatend(20);
    dl.insertatend(50);
    dl.insertatend(20);
    dl.insertatend(10);
    dl.size();
    if(dl.palindrome()){
        cout<<"Palindrome";
    }
    else{
        cout<<"Not Palindrome";
    }
    
}
