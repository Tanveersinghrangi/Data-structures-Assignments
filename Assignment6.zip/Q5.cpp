#include<iostream>
using namespace std;

class node{
    public:
    int data;
    node* next;

    node(int value){
        data=value;
        next=nullptr;
    }
};

class linkedlist{
    public:
    node* head;

    linkedlist(){
        head=nullptr;
    }

    void insert(int value){
        node *n=new node(value);
        if(head==nullptr){
            head=n;
            return;
        }
        node *temp=head;
        while(temp->next!=nullptr){
            temp=temp->next;
        }
        temp->next=n;
    }

    bool isCircular(){
        if(head==nullptr){
            return true;
        }
        node *temp=head->next;
        while(temp!=nullptr && temp!=head){
            temp=temp->next;
        }
        return (temp==head);
    }

    void display(){
        node *temp=head;
        while(temp!=nullptr){
            cout<<temp->data;
            if(temp->next!=nullptr) cout<<"->";
            temp=temp->next;
        }
    }
};

int main(){
    linkedlist l;
    l.insert(2);
    l.insert(4);
    l.insert(6);
    l.insert(7);
    l.insert(5);

    cout<<"LinkedList: ";
    l.display();
    cout<<endl;

    if(l.isCircular()){
        cout<<"True";
    }
    else{
        cout<<"False";
    }
}
