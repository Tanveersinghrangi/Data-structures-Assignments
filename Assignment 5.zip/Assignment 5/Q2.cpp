#include <iostream>
#include <vector>
using namespace std;

class node {
public:
    int data;
    node* next;
    node(int val) {
        data = val;
        next = nullptr;
    }
};

node* convert(vector<int>& arr) {
    if (arr.empty()) return nullptr;
    node* head = new node(arr[0]);
    node* temp = head;
    for (int i = 1; i < arr.size(); i++) {
        temp->next = new node(arr[i]);
        temp = temp->next;
    }
    return head;
}

void display(node* head) {
    node* temp = head;
    while (temp != nullptr) {
        cout << temp->data;
        if (temp->next != nullptr) cout << "->";
        temp = temp->next;
    }
    cout << endl;
}

node* deletekey(node* head, int key, int& count) {
    while (head != nullptr && head->data == key) {
        node* temp = head;
        head = head->next;
        delete temp;
        count++;
    }
    node* curr = head;
    while (curr != nullptr && curr->next != nullptr) {
        if (curr->next->data == key) {
            node* temp = curr->next;
            curr->next = curr->next->next;
            delete temp;
            count++;
        } else {
            curr = curr->next;
        }
    }
    return head;
}

int main() {
    vector<int> arr = {1,2,1,2,2,36,1};
    node* head = convert(arr);
    int key = 1, count = 0;
    head = deletekey(head, key, count);
    cout << "Count: " << count << endl;
    cout<<"Linked List after deletion: ";
    display(head);
    system("pause");    
    return 0;
}