#include <iostream>
#include <vector>
using namespace std;

class node {
public:
    int data;
    node* next;
    node(int value) {
        data = value;
        next = nullptr;
    }
};
node* convert(vector<int>& arr) {
    if (arr.empty()) return nullptr;

    node* head = new node(arr[0]);
    node* temp = head;
    for (int i = 1; i < arr.size(); i++) {
        temp->next = new node(arr[i]);
        temp = temp->next;
    }
    return head;
}

void display(node* head) {
    node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

node* middle(node* head) {
    if (head == nullptr) return nullptr;

    node* slow = head;
    node* fast = head;

    
    while (fast != nullptr && fast->next != nullptr) {
        slow = slow->next;
        fast = fast->next->next;
    }

    return slow; 
}
int main() {
    vector<int> arr = {2, 5, 7, 8, 4, 9};
    node* head = convert(arr);
    cout << "Linked List: ";
    display(head);

    node* mid = middle(head);
    if (mid != nullptr)
        cout << "Middle element: " << mid->data << endl;
    else
        cout << "List is empty" << endl;
    system("pause");    
    return 0;
}
