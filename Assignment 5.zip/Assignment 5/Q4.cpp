#include <iostream>
#include <vector>
using namespace std;

class node {
public:
    int data;
    node* next;
    node(int val) {
        data = val;
        next = nullptr;
    }
};

node* convert(vector<int>& arr) {
    if (arr.empty()) return nullptr;
    node* head = new node(arr[0]);
    node* temp = head;
    for (int i = 1; i < arr.size(); i++) {
        temp->next = new node(arr[i]);
        temp = temp->next;
    }
    return head;
}

void display(node* head) {
    node* temp = head;
    while (temp != nullptr) {
        cout << temp->data;
        if (temp->next != nullptr) cout << "->";
        temp = temp->next;
    }
    cout << "NULL" << endl;
}

node* reverse(node* head) {
    node* prev = nullptr;
    node* curr = head;
    node* next = nullptr;
    while (curr != nullptr) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    return prev;
}

int main() {
    vector<int> arr = {1,2,3,4};
    node* head =convert(arr);
    head =reverse(head);
    display(head);
    system("pause");    
    return 0;
}
