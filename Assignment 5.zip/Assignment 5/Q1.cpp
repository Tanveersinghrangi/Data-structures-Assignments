#include <iostream>
#include <vector>
using namespace std;

class node {
public:
    int data;
    node* next;
    node(int data1) {
        data = data1;
        next = nullptr;
    }
};

node* convert(vector<int> &arr) {
    if (arr.empty()) return nullptr;
    node* head = new node(arr[0]);
    node* mover = head;
    for (int i = 1; i < arr.size(); i++) {
        node* temp = new node(arr[i]);
        mover->next = temp;
        mover = temp;
    }
    return head;
}

node* inserthead(node* head, int value) {
    node* temp = new node(value);
    temp->next = head;
    return temp;
}

node* insertvalue(node* head, int value, int position) {
    if (position == 0) {
        node* newnode = new node(value);
        newnode->next = head;
        return newnode;
    }
    node* temp = head;
    int cnt = 0;
    while (temp != nullptr && cnt < position - 1) {
        temp = temp->next;
        cnt++;
    }
    if (temp == nullptr) return head;
    node* newnode = new node(value);
    newnode->next = temp->next;
    temp->next = newnode;
    return head;
}

node* inserttail(node* head, int value) {
    node* newnode = new node(value);
    if (head == nullptr) return newnode;
    node* temp = head;
    while (temp->next != nullptr) {
        temp = temp->next;
    }
    temp->next = newnode;
    return head;
}

node* deletehead(node* head) {
    if (head == nullptr) return nullptr;
    node* temp = head;
    head = head->next;
    delete temp;
    return head;
}

node* deletetail(node* head) {
    if (head == nullptr || head->next == nullptr) {
        delete head;
        return nullptr;
    }
    node* temp = head;
    while (temp->next->next != nullptr) {
        temp = temp->next;
    }
    delete temp->next;
    temp->next = nullptr;
    return head;
}

node* deletevalue(node* head, int key) {
    while (head != nullptr && head->data == key) {
        node *temp = head;
        head = head->next;
        delete temp;
    }
    node* current = head;
    while (current != nullptr && current->next != nullptr) {
        if (current->next->data == key) {
            node* temp = current->next;
            current->next = current->next->next;
            delete temp;
        } else {
            current = current->next;
        }
    }
    return head;
}

void display(node* head) {
    node* temp = head;
    while(temp != nullptr) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    vector<int> arr = {2, 5, 5, 7};
    node* head = convert(arr);
    int choice, value, pos;

    do {
        cout << "\n1. Display\n2.Insert at Head\n3. Insert at Tail\n4. Insert at Position\n5. Delete Head\n6. Delete Tail\n7. Delete by Value\n8. Exit\nEnter choice: ";
        cin >> choice;
        switch (choice) {
            case 1:
                display(head);
                break;
            case 2: 
                cout <<"Enter value: ";
                cin >> value;
                head = inserthead(head, value);
                break;
            case 3:
                cout <<"Enter value: ";
                cin >> value;
                head = inserttail(head, value);
                break;
            case 4:
                cout <<"Enter value and position: ";
                cin >> value >> pos;
                head = insertvalue(head, value, pos);
                break;
            case 5:
                head = deletehead(head);
                break;
            case 6:
                head = deletetail(head);
                break;
            case 7:
                cout << "Enter value to delete: ";
                cin >> value;
                head = deletevalue(head, value);
                break;
            case 8:
                cout <<"Exiting..." << endl;
                break;
            default:
                cout << "Invalid choice!" << endl;
        }
    } while (choice != 8);
system("pause");    
    return 0;
}
