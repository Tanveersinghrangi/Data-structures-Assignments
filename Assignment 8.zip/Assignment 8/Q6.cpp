#include<iostream>
using namespace std;

class priorityq {
public:
    int arr[100];
    int size;

    priorityq() {
        size = 0;
    }
    void insert(int val) {
        size++;
        int i = size;
        arr[i] = val;

        while (i>1 && arr[i]>arr[i / 2]) {
            swap(arr[i], arr[i / 2]);
            i = i / 2;
        }
    }

    void heapify(int i) {
        int largest = i;
        int left = 2*i;
        int right = 2*i+1;

        if (left <= size && arr[left] > arr[largest])
            largest = left;

        if (right <= size && arr[right] > arr[largest])
            largest = right;

        if (largest != i) {
            swap(arr[i], arr[largest]);
            heapify(largest);
        }
    }
    int extractMax() {
        if (size == 0) {
            cout << "Priority queue is empty\n";
            return -1;
        }

        int maxVal = arr[1];
        arr[1] = arr[size];
        size--;

        heapify(1);

        return maxVal;
    }
    int getMax() {
        if (size == 0) {
            cout << "Priority queue is empty\n";
            return -1;
        }
        return arr[1];
    }

    // Display heap
    void display() {
        if (size == 0) {
            cout << "Priority Queue is empty\n";
            return;
        }

        cout << "Priority Queue: ";
        for (int i = 1; i <= size; i++)
            cout << arr[i] << " ";
        cout << endl;
    }
};


int main() {
    priorityq pq;

    pq.insert(10);
    pq.insert(20);
    pq.insert(56);
    pq.insert(43);
    pq.insert(81);

    pq.display();

    cout << "Max = " << pq.getMax() << endl;
    cout << "Extracted = " << pq.extractMax() << endl;

    pq.display();

    return 0;
}
