#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node *left;
    Node *right;

    Node(int val) {
        data = val;
        left  = nullptr;
        right = nullptr;
    }
};

Node* insertNode(Node* root, int val) {
    if (root == nullptr) {
        return new Node(val);
    }
    if (val < root->data) {
        root->left = insertNode(root->left, val);
    }
    else {
        root->right = insertNode(root->right, val);
    }

    return root; 
    
}

Node* searchRecursive(Node* root, int key) {

    if (root == nullptr || root->data == key) {
        return root;
    }
    if (key < root->data) {
        return searchRecursive(root->left, key);
    }
    return searchRecursive(root->right, key);
}

Node* searchIterative(Node* root, int key) {

    while (root != nullptr && root->data != key) {

        if (key < root->data) {
            root = root->left;
        }
        else {
            root = root->right;
        }
    }
    return root;
}

Node* findMax(Node* root) {
    if (root == nullptr) {
        return nullptr;
    }
    while (root->right != nullptr) {
        root = root->right;
    }
    return root;
}

Node* findMin(Node* root) {
    if (root == nullptr) {
        return nullptr;
    }
    while (root->left != nullptr) {
        root = root->left;
    }
    return root;
}

Node* inorderSuccessor(Node* root, Node* target) {

    if (target == nullptr) {
        return nullptr;
    }
    if (target->right != nullptr) {
        return findMin(target->right);
    }
    Node* successor = nullptr;

    while (root != nullptr) {

        if (target->data < root->data) {
            successor = root;
            root = root->left;
        }
        else if (target->data > root->data) {
            root = root->right;
        }
        else {
            break;
        }
    }

    return successor;
}

Node* inorderPredecessor(Node* root, Node* target) {

    if (target == nullptr) {
        return nullptr;
    }
    if (target->left != nullptr) {
        return findMax(target->left);
    }
    Node* predecessor = nullptr;

    while (root != nullptr) {

        if (target->data > root->data) {
            predecessor = root;
            root = root->right;
        }
        else if (target->data < root->data) {
            root = root->left;
        }
        else {
            break;
        }
    }

    return predecessor;
}

int main() {

    Node* root = nullptr;

    int arr[] = {20, 8, 22, 4, 12, 10, 14};

    for (int x : arr) {
        root = insertNode(root, x);
    }

    Node* keyNode = searchIterative(root, 10);

    cout << "Max = " << findMax(root)->data << endl;
    cout << "Min = " << findMin(root)->data << endl;

    Node* succ = inorderSuccessor(root, keyNode);
    Node* pred = inorderPredecessor(root, keyNode);

    if (succ) cout << "Successor of 10 = " << succ->data << endl;
    else      cout << "No successor\n";

    if (pred) cout << "Predecessor of 10 = " << pred->data << endl;
    else      cout << "No predecessor\n";

    return 0;
}
