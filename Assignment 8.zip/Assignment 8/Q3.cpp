#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node *left;
    Node *right;

    Node(int val) {
        data = val;
        left  = nullptr;
        right = nullptr;
    }
};

Node* insertNode(Node* root, int val) {
    if (root == nullptr) {
        return new Node(val);
    }
    if (val < root->data) {
        root->left = insertNode(root->left, val);
    }
    else if(val>root->data){
        root->right = insertNode(root->right, val);
    }
    else{
        cout<<"Duplicate element will not get inserted";
    }

    return root; 
    
}
Node* findMin(Node* root) {
    while (root && root->left != nullptr)
        root = root->left;
    return root;
}
int maxdepth(Node *root){
    if(root==nullptr){
        return 0;
    }
    int leftdepth=maxdepth(root->left);
    int rightdepth=maxdepth(root->right);
    
    return max(leftdepth,rightdepth)+1;
}
Node *deletenode(Node *root,int val){
   if(root==nullptr){
       return root;
   }
   if(val>root->data){
       root->right=deletenode(root->right,val);
   }
  else if(val<root->data){
       root->left=deletenode(root->left,val);
   }
   else{
       
       if(root->left==nullptr && root->right==nullptr){
           delete root;
           return nullptr;
       }
       else if(root->left==nullptr){
           Node *temp=root->right;
           delete root;
           return temp;
       }
       else if(root->left==nullptr){
           Node *temp=root->left;
           delete root;
           return temp;
       }
       else {
           Node *minval=findMin(root->right);
           root->data=minval->data;
           root->right=deletenode(root->right,minval->data);
       }
   }
    return root;
    
}
void preorder(Node* root){
    if(root==nullptr){
        return ;
    }
    cout<<root->data<<endl;
    preorder(root->left);
    preorder(root->right);
    
    
}
int main() {

    Node* root = nullptr;

    int arr[] = {20, 8, 22, 4, 12, 10, 14};

    for (int x : arr) {
        root = insertNode(root, x);
    }
  preorder(root);
  Node* updat=deletenode(root,22);
  preorder(updat);
  int a=maxdepth(root);
  cout<<a;

}
