#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node *left;
    Node *right;

    Node(int val) {
        data = val;
        left  = nullptr;
        right = nullptr;
    }
};

Node* insertNode(Node* root, int val) {
    if (root == nullptr) {
        return new Node(val);
    }
    if (val < root->data) {
        root->left = insertNode(root->left, val);
    }
    else {
        root->right = insertNode(root->right, val);
    }

    return root; 
    
}

Node* findMax(Node* root) {
    if (root == nullptr) {
        return nullptr;
    }
    while (root->right != nullptr) {
        root = root->right;
    }
    return root;
}

Node* findMin(Node* root) {
    if (root == nullptr) {
        return nullptr;
    }
    while (root->left != nullptr) {
        root = root->left;
    }
    return root;
}

bool isBST(Node* root) {

    if (root == nullptr)
        return true;

   
    if (root->left != nullptr) {
        Node* maxLeft = findMax(root->left);
        if (maxLeft->data >= root->data)
            return false;
    }

   
    if (root->right != nullptr) {
        Node* minRight = findMin(root->right);
        if (minRight->data <= root->data)
            return false;
    }
    return isBST(root->left) && isBST(root->right);
}


int main() {

    Node* root = nullptr;

    int arr[] = {20, 8, 22, 4, 12, 10, 14};

    for (int x : arr) {
        root = insertNode(root, x);
    }
    if(!isBST(root)){
        cout<<"No it isn't a bst"<<endl;
    }
    else{
        cout<<"Yes it is a bst";
    }

}
