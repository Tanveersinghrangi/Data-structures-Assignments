#include<iostream>
using namespace std;

class node{
    public:
    int data;
    node *leftchild;
    node *rightchild;
    node(int val){
         data=val;
        leftchild=nullptr;
        rightchild=nullptr;
    }
};

    void preorder(node *ptr){
        if(ptr==nullptr){
            return;
        }
        cout<<ptr->data;
        cout<<" ";
        preorder(ptr->leftchild);
        preorder(ptr->rightchild);
    }
    void inorder(node *ptr){
       if(ptr==nullptr){
            return;
        }
        inorder(ptr->leftchild);
         cout<<ptr->data;
         cout<<" ";
        inorder(ptr->rightchild);
    }
    void postorder(node *ptr){
        if(ptr==nullptr){
            return;
        }
        postorder(ptr->leftchild);
        postorder(ptr->rightchild);
        cout<<ptr->data;
        cout<<" ";
    }
    
    int main(){
        node *root =new node(15);
        root->leftchild=new node(26);
        root->rightchild=new node(35);
        root->leftchild->leftchild=new node(33);
        root->leftchild->rightchild=new node(78);
        preorder(root);
        cout<<endl;
        inorder(root);
         cout<<endl;
         postorder(root);
         cout<<endl;
        
        
    }
    
    
    
    
    
    
    
    
    
